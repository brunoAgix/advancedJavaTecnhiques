package binaryOperations;

@FunctionalInterface
public interface BinaryOperation {
    abstract int apply(int x, int y);
}
